# Microelectronic_Circuits
Assignment of Microelectronic Circuits using HSPICE to simulate some of CMOS gates logics.
